# cs4620sp-computer-graphic
homework

name: Siyao Huang NetID: sh2435
There is no problem in my solustion
nothing
