package common;


public class Skeleton {
	public static final int MAX_BONES = 32;
	
}
