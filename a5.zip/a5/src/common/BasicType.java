package common;

public enum BasicType {
	Sphere,
	Cube,
	Cylinder,
	TriangleMesh
}
