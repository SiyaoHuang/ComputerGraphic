package common.event;

public enum SceneDataType {
	Mesh,
	Texture,
	Material,
	Object,
	Cubemap,
	None
}
