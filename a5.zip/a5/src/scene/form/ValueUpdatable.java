package scene.form;

public interface ValueUpdatable {
	void updateValues();
}
